.. dj-booking documentation master file, created by
   Foad Heidari on Wed Aug  22 23:17:42 2021.

.. include:: ../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   overview
   installation
   configuration


==================
Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
