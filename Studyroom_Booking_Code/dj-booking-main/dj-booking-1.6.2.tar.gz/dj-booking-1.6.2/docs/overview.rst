Overview
========

Requirements
------------

- Python 3.5, 3.6, 3.7, 3.8 or 3.9

- Django (2.0+)


Supported Flows
---------------

- Create a new booking

- Manage bookings

- Approve or Remove each booking

- Overview of bookings

- List of all booking

- Able to limit booking for each day or each time
